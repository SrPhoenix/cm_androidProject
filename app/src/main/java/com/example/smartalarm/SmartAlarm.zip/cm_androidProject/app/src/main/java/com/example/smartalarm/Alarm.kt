package com.example.smartalarm

data class Alarm(val id: Int, val label: String, val hour: Int, val minute: Int)
